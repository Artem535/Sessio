#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
spike_cache=/home/a.durynin/.cache/sessio-llm-spike-146
spike_python="$spike_cache/litert-venv/bin/python"
spike_model="$spike_cache/litert-e4b/gemma-4-E4B-it.litertlm"
spike_reference="$spike_cache/onnx-export/Q4_K_M/default"
"$spike_python" prepare_prompt_ab.py
for variant in baseline rules examples; do
  systemd-run --user --scope -p MemoryMax=5G -p MemorySwapMax=0 \
    "$spike_python" compare_litert.py --mtp --repeats 2 --model "$spike_model" \
    --template "$spike_reference/chat_template.jinja" --cases-file prompt-ab-cases.json \
    --prompt-file "prompts/$variant-extract.txt" --out "results/prompt-$variant-short.json" \
    >"results/prompt-$variant-short.log" 2>&1
  echo "$variant short complete"
  systemd-run --user --scope -p MemoryMax=5G -p MemorySwapMax=0 \
    "$spike_python" compare_litert.py --mtp --repeats 2 --max-tokens 256 --model "$spike_model" \
    --template "$spike_reference/chat_template.jinja" --cases-file long-cases.json \
    --prompt-file "prompts/$variant-extract.txt" --out "results/prompt-$variant-long.json" \
    >"results/prompt-$variant-long.log" 2>&1
  echo "$variant long complete"
  systemd-run --user --scope -p MemoryMax=5G -p MemorySwapMax=0 \
    "$spike_python" rolling_state.py --patch --mutation-probe --backend litert \
    --litert-model "$spike_model" --model-dir "$spike_reference" \
    --cases-file long-cases.json --windows-file rolling-windows.json \
    --prompt-file "prompts/$variant-patch.txt" --out "results/prompt-$variant-patch.json" \
    >"results/prompt-$variant-patch.log" 2>&1
  echo "$variant patch complete"
done
