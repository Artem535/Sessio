# Throwaway spike #146; never linked into Sessio.
"""Report latency; semantic accuracy requires independent manual annotation."""
import argparse
import json
import statistics

def unwrapped_json(raw):
    text = raw.strip()
    if text.startswith("```json\n") and text.endswith("\n```"):
        text = text[8:-4].strip()
    return json.loads(text)

def percentile(values, fraction):
    values = sorted(values)
    position = (len(values) - 1) * fraction
    lo = int(position)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (position - lo)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+")
    args = parser.parse_args()
    print("| Label | n | TTFT median s | Complete median s | Complete p95 s | Raw JSON valid | JSON after fence removal |")
    print("|---|---:|---:|---:|---:|---:|---:|")
    for name in args.files:
        with open(name) as file:
            rows = json.load(file)
        if not rows:
            raise ValueError(f"Empty result file: {name}")
        elapsed = [row["complete_s"] for row in rows]
        ttft = [row["ttft_s"] for row in rows if row["ttft_s"] is not None]
        first = f"{statistics.median(ttft):.3f}" if ttft else "n/a"
        p95 = f"{percentile(elapsed, .95):.3f}" if len(rows) >= 20 else "insufficient n"
        parsed = 0
        for row in rows:
            try:
                unwrapped_json(row["raw"])
                parsed += 1
            except json.JSONDecodeError:
                pass
        print(f"| {rows[0]['label']} | {len(rows)} | {first} | "
              f"{statistics.median(elapsed):.3f} | {p95} | "
              f"{sum(row['valid_json'] for row in rows)}/{len(rows)} | {parsed}/{len(rows)} |")

if __name__ == "__main__":
    main()
