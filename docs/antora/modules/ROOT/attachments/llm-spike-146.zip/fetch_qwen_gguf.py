"""Reuse verified range downloader for pinned Qwen GGUF; separate cache root."""
from pathlib import Path
import fetch_embedding as download

download.REPO = 'unsloth/Qwen3.5-4B-GGUF'
download.REVISION = 'e87f176479d0855a907a41277aca2f8ee7a09523'
download.NAME = 'Qwen3.5-4B-Q8_0.gguf'
download.ROOT = Path('/home/a.durynin/.cache/sessio-llm-spike-146/qwen-gguf')
download.SIZE = 4482403488

if __name__ == '__main__':
    partial = download.ROOT / (download.NAME + '.partial')
    chunks = download.ROOT / 'embedding-chunks'
    chunks.mkdir(exist_ok=True)
    if partial.exists():
        with partial.open('rb') as source:
            for i in range(partial.stat().st_size // download.CHUNK):
                chunk = chunks / f'{i:04d}'
                if not chunk.exists():
                    chunk.write_bytes(source.read(download.CHUNK))
                else:
                    source.seek(download.CHUNK, 1)
    download.main()
