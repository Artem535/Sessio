"""Pinned Phi-4-mini Q4_K_M, exact ranges and upstream SHA256 verification."""
from pathlib import Path
import fetch_embedding as download

download.REPO = 'bartowski/microsoft_Phi-4-mini-instruct-GGUF'
download.REVISION = '7ff82c2aaa4dde30121698a973765f39be5288c0'
download.NAME = 'microsoft_Phi-4-mini-instruct-Q4_K_M.gguf'
download.ROOT = Path('/home/a.durynin/.cache/sessio-llm-spike-146/phi-gguf')
download.SIZE = 2491874688

if __name__ == '__main__':
    download.ROOT.mkdir(parents=True, exist_ok=True)
    download.main()
