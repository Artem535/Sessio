"""Synthetic long call with accepted facts near start, middle and end."""
import argparse
import json
from pathlib import Path
from tokenizers import Tokenizer
from compare_cpu import template
from bench import SYSTEM

p = argparse.ArgumentParser()
p.add_argument('--model-dir', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
args = p.parse_args()
encoder = Tokenizer.from_file(str(args.model_dir / 'tokenizer.json'))
render = template(args.model_dir / 'chat_template.jinja')
start = '[a1] Специалист: Давайте встретимся в пятницу в 18:00.\n[a2] Клиент: Да, договорились.'
middle = '[b1] Клиент: Пришлю записи завтра.\n[b2] Клиент: Исправлю: пришлю записи в понедельник.\n[b3] Специалист: Хорошо, в понедельник.'
end = '[c1] Специалист: Может быть, будете вести дневник каждый день?\n[c2] Клиент: Нет, я этого не обещаю. Новых договоренностей пока нет.'
filler = [
    'Клиент: Вчера было трудно сосредоточиться, несколько раз отвлекался на сообщения.',
    'Специалист: Что происходило перед тем, как вы заметили это?',
    'Клиент: Я вспоминал разговор на работе и пытался понять, почему он меня задел.',
    'Специалист: Расскажите подробнее о своих ощущениях в тот момент.',
    'Клиент: Сначала чувствовал напряжение, потом стало спокойнее после прогулки.',
    'Специалист: Мы сейчас разбираем прошлую ситуацию, новых задач или сроков не назначаем.',
]
def history(n):
    lines = [f'[f{i+1}] {filler[i % len(filler)]}' for i in range(n)]
    return '\n'.join([start, *lines[:n//2], middle, *lines[n//2:], end])
def count(text):
    raw = render.render(messages=[{'role':'system','content':SYSTEM},
        {'role':'user','content':text}], tools=None, bos_token='<bos>',
        enable_thinking=False, add_generation_prompt=True)
    return len(encoder.encode(raw, add_special_tokens=False).ids)
n = 0
while count(history(n+1)) <= 3000:
    n += 1
cases = [['short_control', history(0), ['a1','a2','b2','b3']],
         ['long_3000', history(n), ['a1','a2','b2','b3']]]
args.out.write_text(json.dumps(cases, ensure_ascii=False, indent=2)+'\n')
print([(name, count(text)) for name,text,_ in cases])
