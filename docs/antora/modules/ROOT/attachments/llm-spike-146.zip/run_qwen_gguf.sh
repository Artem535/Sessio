#!/usr/bin/env bash
# CPU-only fallback. Expects a separately started server and its PID.
set -euo pipefail
cd "$(dirname "$0")"
spike_cache=/home/a.durynin/.cache/sessio-llm-spike-146
spike_python="$spike_cache/litert-venv/bin/python"
spike_reference="$spike_cache/litert-qwen4"
spike_pid="$1"
"$spike_python" compare_cpu.py --backend llama --server-pid "$spike_pid" \
  --repeats 2 --model-dir "$spike_reference" --out results/qwen-gguf-short.json \
  >results/qwen-gguf-short.log 2>&1
echo 'Qwen GGUF short complete'
"$spike_python" compare_cpu.py --backend llama --server-pid "$spike_pid" \
  --repeats 2 --max-tokens 256 --cases-file long-cases.json \
  --model-dir "$spike_reference" --out results/qwen-gguf-long.json \
  >results/qwen-gguf-long.log 2>&1
echo 'Qwen GGUF long complete'
"$spike_python" rolling_state.py --patch --mutation-probe --backend llama \
  --server-pid "$spike_pid" --model-dir "$spike_reference" \
  --cases-file long-cases.json --windows-file rolling-windows.json \
  --out results/qwen-gguf-patch.json >results/qwen-gguf-patch.log 2>&1
echo 'Qwen GGUF patch complete'
