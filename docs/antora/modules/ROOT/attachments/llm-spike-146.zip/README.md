# Live LLM spike #146

Throwaway harness, separate from Sessio. `bench.py` uses the Python standard library;
comparative runners need the pinned dependency files.
Sources and complete evaluation plan: `docs/live-llm-research.md`.

## LiteRT-LM CPU

Qwen INT8 diagnostic/fallback notes: `docs/live-llm-qwen4-results.md`.
The text-only export requires `--text-only` (audio/vision backend None); its MTP
heads are absent, so omit `--mtp` / pass `--no-mtp` to the rolling runner.
Gemma keeps its previous CPU multimodal settings. BOS normalization is applied
only when the rendered prompt actually starts with Gemma's literal `<bos>`.
`--windows-file rolling-windows.json` freezes the original Gemma utterance
boundaries for a different tokenizer. No oracle state is introduced.
`qwen_diagnostic.py --fp32` checks two low-level sessions; `--conversation`
checks the native high-level API with a new engine on each probe.
`fetch_qwen_gguf.py` downloads the pinned GGUF with verified HTTP byte ranges and
SHA256. After starting its CPU llama-server, `bash run_qwen_gguf.sh <server-pid>`
runs short/long cases twice and operation-state replays twice. Do not merge
malformed-output diagnostic latencies with usable-answer latency comparisons.

E4B replay of the unchanged short, long, and operation prompts is available via
`bash run_e4b.sh`. Pin/verify the export as documented in
`docs/live-llm-e4b-results.md` before running. The script executes sequential CPU
scopes with 12-GiB memory/no-swap limits; no GPU backend is selected.

`rolling_state.py` replays the long fixture in whole-utterance windows capped at
450 transcript tokens. Required flags: `--backend litert|llama --model-dir
"$ORT_MODEL" --cases-file long-cases.json --out results/<name>.json`.
LiteRT also needs `--litert-model "$LITERT_MODEL"`; llama needs
`--server-pid <pid>` for memory sampling and the running CPU server on port 8146.
Default two replays use only model-generated previous state. `--patch` enables
an application-maintained ledger with model-generated upsert/remove operations.
`--mutation-probe` appends explicit rescheduling, cancellation, and neutral turns.
Use the same bounded user scope as other LiteRT runs. Inspect all raw transitions
and rejected operations; parseable JSON and retained state are not semantic proof.

For the long-context comparison, generate `long-cases.json` with
`make_long_cases.py --model-dir "$ORT_MODEL" --out long-cases.json`.
Both runners accept `--cases-file long-cases.json --max-tokens 256`.
Use `--mtp` for the tested LiteRT configuration. The fixture has a 271-token
control and a 2986-token history with identical fact-bearing turns.
See `docs/live-llm-long-results.md` for latency and retention limitations.

Install `requirements-litert.txt` in a separate Python 3.12 venv. Download
`gemma-4-E2B-it.litertlm` from `litert-community/gemma-4-E2B-it-litert-lm`,
revision `b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1`, SHA256
`181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c`.
Use the same `chat_template.jinja` and `tokenizer.json` as the ORT comparison.

```bash
systemd-run --user --scope -p MemoryMax=8G -p MemorySwapMax=0 \
  "$LITERT_PYTHON" compare_litert.py --model "$LITERT_MODEL" \
  --template "$ORT_MODEL/chat_template.jinja" --out results/litert-cpu.json
# Repeat with --mtp and a different output filename.
```

The runner explicitly selects CPU for every component, uses four threads,
greedy sampling, 4096 context and 160 output tokens. Each request gets a fresh
session. Weight compilation cache is permitted; prompt reuse is disabled.
LiteRT inserts BOS during prefill, so the literal BOS is omitted only for its
raw text API. Remaining token IDs and measured input counts are checked.
Registered GPU accelerator names in startup logs are library registration;
all selected execution backends are CPU. Results compare different quantized
exports, not isolated runtime efficiency. See `docs/live-llm-litert-results.md`.

```bash
LLAMA=/home/a.durynin/llama.cpp/build/bin
MODEL=/home/a.durynin/.cache/sessio-llm-spike-146/gemma-4-E2B-it-Q4_0.gguf
$LLAMA/llama-bench -m "$MODEL" -p 512,2048 -n 80 -t 4 -ngl 0 -r 5 -o json
$LLAMA/llama-server -m "$MODEL" -c 4096 -t 4 -ngl 0 --reasoning off --port 8146 --host 127.0.0.1
# In a second terminal, from this directory:
python3 bench.py --label gemma-e2b-cpu-t4 --repeats 3 --out results/e2b-cpu.json
python3 bench.py --label gemma-e2b-cpu-t4-cached --cache --repeats 3 --out results/e2b-cpu-cached.json
python3 report.py results/e2b-cpu.json
```

**GPU runs suspended:** the first Vulkan attempt coincided with a host crash.
The cause is unresolved. Do not repeat device initialization or GPU benchmarks
automatically; the research note records the available evidence.

For a future investigated Vulkan build with `-DGGML_VULKAN=ON`, confirm `--list-devices` reports
Radeon 780M (not llvmpipe), then select that device and `-ngl 99`.
Record the startup log proving actual layer offload. Stop CPU server first.
Keep the same model/context/sampler and do not run benchmarks concurrently.

This run used llama.cpp commit `fc35562ba46fbbf8e30cac85edbb39642c37d248`.
Vulkan tools were extracted locally from Fedora 44 RPMs rather than installed:
`glslc-2026.1-1.fc44.x86_64` and `spirv-headers-devel-1.5.5-45.fc44.noarch`.
With their extracted `usr` directory at `$SDK`, the build command is:

```bash
cmake -S /home/a.durynin/llama.cpp -B /home/a.durynin/llama.cpp/build-spike-146-vulkan \
  -DCMAKE_BUILD_TYPE=Release -DGGML_VULKAN=ON -DLLAMA_BUILD_UI=OFF \
  -DCMAKE_PREFIX_PATH="$SDK/usr" -DCMAKE_CXX_FLAGS="-I$SDK/usr/include" \
  -DVulkan_GLSLC_EXECUTABLE="$SDK/usr/bin/glslc"
cmake --build /home/a.durynin/llama.cpp/build-spike-146-vulkan --parallel 4 \
  --target llama-server llama-bench
```

Set SDK to `/home/a.durynin/.cache/sessio-llm-spike-146/shaderc` on this machine.
Weights SHA256 is in the research note. Build logs are in the same cache root.

TTFT excludes reasoning deltas and ends at first content delta; completion
includes reading the full SSE response. JSON validity is syntactic only;
human review must verify evidence and semantics. `finish_reason=length` means
the output may be truncated. Six scenarios do not establish production quality.
This first harness does not simulate scheduler, ASR, long context, or a call.

## CPU runtime comparison

`compare_cpu.py` compares the exact same rendered chat-template prompt through
llama-server `/completion` and ORT GenAI's native generation API. Both use greedy
decode, thinking off, 4K context, no prompt caching and no constrained grammar.
The earlier `bench.py` results used JSON schema and are a separate experiment.
The ORT artifact quantizes the decoder to INT4 Q4_K_M; large embeddings remain
unquantized. This is not the same quantization as the GGUF Q4_0 baseline.
llama receives explicit IDs from the exported tokenizer, avoiding an extra BOS
that its native string-prompt API would otherwise insert.
ORT includes the package's audio/vision graphs but receives text input only.

```bash
uv venv --python 3.12 /home/a.durynin/.cache/sessio-llm-spike-146/ort-venv
uv pip install --python /home/a.durynin/.cache/sessio-llm-spike-146/ort-venv/bin/python \
  -r requirements-ort.txt
# Download only Q4_K_M/default/* from the pinned repository revision:
# justinchuby/gemma-4-e2b-it-onnx @ 9bcf2cb1c2878b1c68a5f94db037272dfb278384
PY=/home/a.durynin/.cache/sessio-llm-spike-146/ort-venv/bin/python
ORT_MODEL=/home/a.durynin/.cache/sessio-llm-spike-146/onnx-export/Q4_K_M/default
# Start the CPU-only llama-server as above; note its PID for RSS monitoring.
$PY compare_cpu.py --backend llama --model-dir "$ORT_MODEL" --server-pid SERVER_PID \
  --repeats 4 --out results/llama-cpu-matched.json
# Stop llama-server, then run ORT alone in a bounded user scope:
systemd-run --user --scope --unit sessio-146-ort \
  -p MemoryMax=18G -p MemorySwapMax=0 \
  "$PY" compare_cpu.py --backend onnx --model-dir "$ORT_MODEL" \
  --repeats 4 --out results/onnx-cpu-matched.json
$PY report.py results/llama-cpu-matched.json results/onnx-cpu-matched.json
```

ORT CPU session settings are copied into a separate symlink-based model variant
`cpu-t4-c4096`; the downloaded config remains untouched. Metadata records RSS,
runtime version and load time. For llama, RSS is sampled from the server PID;
its startup load time is excluded. ORT RSS includes Python/library overhead.
The sampler can miss short RSS spikes; use the recorded kernel `ru_maxrss` for
ORT's process lifetime peak. For llama, the client's `ru_maxrss` is not server RSS.
Latency includes tokenization and generation; llama also includes local HTTP/SSE.
Warmup is excluded. Review raw outputs and token counts alongside timing.
Do not run downloads, compilations or both inference processes concurrently
with measured runs. These six synthetic cases are a pilot, not a quality dataset.

If the large embedding transfer stalls, `fetch_embedding.py` downloads the
pinned file in two parallel 64-MiB ranges, verifies exact Content-Range/size,
and checks the assembled SHA256 against the repository LFS manifest before
replacing the partial artifact. It preserves downloaded chunks for resumption.

The default model package and an embedding-noopt diagnostic both exceeded a
12-GiB cgroup memory limit at model load. The measured run uses an 18-GiB limit
on the 27-GiB host after stopping llama-server. Do not copy that limit to a
machine without adequate available RAM. An experimental text-only config did
not load: this package cannot disable its audio/vision components merely by
blanking filenames. Those failures are not throughput measurements.

## Phi-4-mini CPU probe

`fetch_phi_gguf.py` downloads pinned Q4_K_M with exact range/size and SHA256
verification. Official tokenizer/template revision is recorded in
`docs/live-llm-phi-results.md`; extract `chat_template` from tokenizer_config.json
into phi-reference/chat_template.jinja beside tokenizer.json.
Start CPU llama-server with four threads, context 4096, `-ngl 0 -np 1`,
port 8146, inside a MemoryMax=4G / MemorySwapMax=0 scope. Then run
`bash run_phi_gguf.sh SERVER_PID`; stop the server after completion.
The measured scope reached its memory cap without OOM, so timings include
possible reclaim pressure. Read the semantic report rather than counting valid
JSON or matching final state as success.

## Gemma E4B prompt comparison

`run_prompt_ab.sh` reruns baseline, reviewed rules, and rules+examples sequentially
on CPU LiteRT+MTP with identical greedy/no-thinking settings. Materialized prompts
come from `prepare_prompt_ab.py`; eleven short cases include five new wordings.
Long fixtures and ten fixed operation windows remain identical. Each run uses
a5GiB no-swap scope; assess available host memory before replaying.
`compare_litert.py` and `rolling_state.py` accept `--prompt-file`; omission
preserves their previous defaults. Report: `docs/live-llm-gemma-prompt-ab-results.md`.
Evidence/action correctness and target matching require semantic review.

## Separate events and target matching

`run_event_quality.sh` runs the final `event_pipeline.py --variant v7 --exact-match`
candidate over four fixed fixtures, two replays each. Earlier variants remain
diagnostics; some have partial results after early failure stops. The final
extractor receives only new utterances; model target matching receives the event,
candidate records and source utterances. Code validates source labels/IDs,
filters candidates by related participants, prefers a unique exact action match,
and rejects unresolved/ambiguous targets. Rejections remain visible in the trace.

`evaluate_event_ledger.py` uses gold ledgers solely after inference, checks complete
replays and exact record/evidence state, and writes an evaluation artifact. It
does not replace manual semantic review or certify safe product automation.
Report: `docs/live-llm-gemma-event-quality.md`. The fresh presentation scenario
still misses one cancellation; integrate as reviewable suggestions with a visible
unresolved-event queue, not silent automatic ledger edits.
