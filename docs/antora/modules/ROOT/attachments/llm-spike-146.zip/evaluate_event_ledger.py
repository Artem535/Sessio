"""Fixture oracle only for evaluation; never passed to inference."""
import json
from pathlib import Path

a={'a1':['a1','a2']}; ab={**a,'b2':['b2','b3']}
changed={'a1':['d1','d2']}
t={'t1':['t1','t2']};tt={**t,'t3':['t3','t4']};tc={'t1':['t7','t8']}
j={'j1':['j1','j2']};jj={**j,'j3':['j3','j4']};jb={'j3':['j3','j4']}
n={'n1':['n1','n2']};nn={**n,'n3':['n3','n4']};nc={'n1':['n5','n6']}
EXPECTED={
    'original':[a,a,a,ab,ab,ab,ab,{**changed,'b2':['b2','b3']},changed,changed],
    'heldout':[t,tt,tt,{**tc,'t3':['t3','t4']},tc,tc,tc,tc],
    'owners':[j,jj,jb,jb,jb,{'j3':['j11','j12']}],
    'fresh':[n,nn,{**nc,'n3':['n3','n4']},nc,nc,nc,nc],
}

if __name__=='__main__':
    summary={}
    for scenario,gold in EXPECTED.items():
        path=Path(f'results/event-final-{scenario}.json')
        rows=json.loads(path.read_text()); failures=[]
        for row in rows:
            actual={item['id']:item['evidence_ids'] for item in row['state']}
            target=gold[row['step']]
            if actual.keys()!=target.keys() or any(set(actual[key])!=set(ids) for key,ids in target.items() if key in actual):
                failures.append(dict(repeat=row['repeat'],step=row['step'],actual=actual,expected=target))
        half=len(rows)//2
        same=all(x['state']==y['state'] and [c['raw'] for c in x['calls']]==[c['raw'] for c in y['calls']]
            for x,y in zip(rows[:half],rows[half:]))
        summary[scenario]=dict(transitions=len(rows),ledger_evidence_pass=len(rows)-len(failures),
            complete=(len(rows)==2*len(gold) and
                {(r['repeat'],r['step']) for r in rows}=={(repeat,step) for repeat in range(2) for step in range(len(gold))}),
            failures=failures,repeat_identical=same,
            truncated=sum(c['truncated'] for row in rows for c in row['calls']),
            parse_failures=sum(c['parsed'] is None for row in rows for c in row['calls']))
    Path('results/event-final-evaluation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
