#!/usr/bin/env bash
# Throwaway CPU-only spike. Downloads must finish before invoking this script.
set -euo pipefail
cd "$(dirname "$0")"
spike_cache=/home/a.durynin/.cache/sessio-llm-spike-146
spike_python="$spike_cache/litert-venv/bin/python"
spike_model="$spike_cache/litert-e4b/gemma-4-E4B-it.litertlm"
spike_reference="$spike_cache/onnx-export/Q4_K_M/default"
systemd-run --user --scope -p MemoryMax=12G -p MemorySwapMax=0 \
  "$spike_python" compare_litert.py --mtp --model "$spike_model" \
  --template "$spike_reference/chat_template.jinja" --out results/e4b-short.json \
  >results/e4b-short.log 2>&1
echo 'E4B short complete'
systemd-run --user --scope -p MemoryMax=12G -p MemorySwapMax=0 \
  "$spike_python" compare_litert.py --mtp --max-tokens 256 \
  --cases-file long-cases.json --model "$spike_model" \
  --template "$spike_reference/chat_template.jinja" --out results/e4b-long.json \
  >results/e4b-long.log 2>&1
echo 'E4B long complete'
systemd-run --user --scope -p MemoryMax=12G -p MemorySwapMax=0 \
  "$spike_python" rolling_state.py --patch --mutation-probe --backend litert \
  --litert-model "$spike_model" --model-dir "$spike_reference" \
  --cases-file long-cases.json --out results/e4b-patch.json \
  >results/e4b-patch.log 2>&1
echo 'E4B patch complete'
