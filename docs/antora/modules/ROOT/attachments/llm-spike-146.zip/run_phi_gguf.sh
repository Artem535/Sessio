#!/usr/bin/env bash
# CPU-only; separately started, memory-bounded single-slot server.
set -euo pipefail
cd "$(dirname "$0")"
spike_cache=/home/a.durynin/.cache/sessio-llm-spike-146
spike_python="$spike_cache/litert-venv/bin/python"
spike_reference="$spike_cache/phi-reference"
spike_pid="$1"
"$spike_python" compare_cpu.py --backend llama --server-pid "$spike_pid" \
  --repeats 2 --model-dir "$spike_reference" --out results/phi-gguf-short.json \
  >results/phi-gguf-short.log 2>&1
echo 'Phi short complete'
"$spike_python" compare_cpu.py --backend llama --server-pid "$spike_pid" \
  --repeats 2 --max-tokens 256 --cases-file long-cases.json \
  --model-dir "$spike_reference" --out results/phi-gguf-long.json \
  >results/phi-gguf-long.log 2>&1
echo 'Phi long complete'
"$spike_python" rolling_state.py --patch --mutation-probe --backend llama \
  --server-pid "$spike_pid" --model-dir "$spike_reference" \
  --cases-file long-cases.json --windows-file rolling-windows.json \
  --out results/phi-gguf-patch.json >results/phi-gguf-patch.log 2>&1
echo 'Phi patch complete'
