#!/usr/bin/env bash
# Throwaway CPU-only final candidate; generated state, no oracle input.
set -euo pipefail
cd "$(dirname "$0")"
spike_python=/home/a.durynin/.cache/sessio-llm-spike-146/litert-venv/bin/python
for scenario in owners original heldout fresh; do
  systemd-run --user --scope -p MemoryMax=5G -p MemorySwapMax=0 \
    "$spike_python" event_pipeline.py --variant v7 --exact-match \
    --windows-file "event-$scenario-windows.json" --out "results/event-final-$scenario.json" \
    >"results/event-final-$scenario.log" 2>&1
  echo "$scenario complete"
done
