# Throwaway spike #146; never linked into Sessio.
"""Same rendered prompt, greedy generation, no grammar/cache for both runtimes."""
import argparse
import json
import os
from pathlib import Path
import resource
import threading
import time
import urllib.request

import psutil
from jinja2.sandbox import ImmutableSandboxedEnvironment
from bench import CASES, SYSTEM


def template(path):
    env = ImmutableSandboxedEnvironment()
    def fail(message):
        raise ValueError(message)
    env.globals["raise_exception"] = fail
    return env.from_string(path.read_text())


def ort_model(source, threads, no_embedding_optimization=False):
    """Keep downloaded config intact; symlink model data into a CPU-only variant."""
    suffix = "-embed-noopt" if no_embedding_optimization else ""
    target = source.parent / f"cpu-t{threads}-c4096{suffix}"
    target.mkdir(exist_ok=True)
    for child in source.iterdir():
        if child.name != "genai_config.json":
            link = target / child.name
            if not link.exists():
                link.symlink_to(child.resolve(), target_is_directory=child.is_dir())
    config = json.loads((source / "genai_config.json").read_text())
    config["model"]["context_length"] = 4096
    config["search"]["max_length"] = 4096
    for component in ("decoder", "embedding", "vision", "speech"):
        options = config["model"][component].setdefault("session_options", {})
        options.update(provider_options=[], intra_op_num_threads=threads,
                       inter_op_num_threads=1)
    if no_embedding_optimization:
        config["model"]["embedding"]["session_options"]["graph_optimization_level"] = "ORT_DISABLE_ALL"
    (target / "genai_config.json").write_text(json.dumps(config, indent=2))
    return target


def llama(url, prompt, maximum, encoder):
    start = time.perf_counter()
    ids = encoder.encode(prompt, add_special_tokens=False).ids
    body = {"prompt": ids, "stream": True, "temperature": 0,
            "seed": 146, "n_predict": maximum, "cache_prompt": False}
    request = urllib.request.Request(url + "/completion", json.dumps(body).encode(),
                                     {"Content-Type": "application/json"})
    first = None
    text = ""
    final = {}
    with urllib.request.urlopen(request, timeout=180) as response:
        for line in response:
            if not line.startswith(b"data: "):
                continue
            value = line[6:].strip()
            if value == b"[DONE]":
                break
            event = json.loads(value)
            delta = event.get("content", "")
            if delta and first is None:
                first = time.perf_counter() - start
            text += delta
            if event.get("stop"):
                final = event
    return dict(raw=text, ttft_s=first, complete_s=time.perf_counter() - start,
                output_tokens=final.get("tokens_predicted"),
                input_tokens=final.get("tokens_evaluated"),
                timings=final.get("timings"),
                truncated=final.get("stopped_limit"))


def ort(og, model, tokenizer, prompt, maximum):
    start = time.perf_counter()
    ids = tokenizer.encode(prompt)
    if len(ids) + maximum > 4096:
        raise ValueError("Prompt exceeds experiment context budget")
    params = og.GeneratorParams(model)
    params.set_search_options(do_sample=False, max_length=len(ids) + maximum,
                              num_beams=1, repetition_penalty=1.0)
    stream = tokenizer.create_stream()
    generator = og.Generator(model, params)
    generator.append_tokens(ids)
    first = None
    text = ""
    count = 0
    while not generator.is_done():
        generator.generate_next_token()
        token = int(generator.get_next_tokens()[0])
        if token in tokenizer.eos_token_ids:
            break
        delta = stream.decode(token)
        if delta and first is None:
            first = time.perf_counter() - start
        text += delta
        count += 1
    elapsed = time.perf_counter() - start
    del generator
    return dict(raw=text, ttft_s=first, complete_s=elapsed,
                input_tokens=len(ids), output_tokens=count,
                truncated=count >= maximum)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["llama", "onnx"], required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--url", default="http://127.0.0.1:8146")
    parser.add_argument("--server-pid", type=int)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--repeats", type=int, default=4)
    parser.add_argument("--max-tokens", type=int, default=160)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cases-file", type=Path)
    parser.add_argument("--ort-no-embedding-optimization", action="store_true")
    args = parser.parse_args()
    cases = json.loads(args.cases_file.read_text()) if args.cases_file else CASES
    render = template(args.model_dir / "chat_template.jinja")
    process = psutil.Process(args.server_pid or os.getpid())
    rss = [process.memory_info().rss]
    stop = threading.Event()
    def monitor():
        while not stop.wait(.05):
            rss.append(process.memory_info().rss)
    watcher = threading.Thread(target=monitor, daemon=True)
    watcher.start()
    start = time.perf_counter()
    if args.backend == "onnx":
        import onnxruntime_genai as og
        model = og.Model(str(ort_model(args.model_dir.resolve(), args.threads,
                                      args.ort_no_embedding_optimization)))
        tokenizer = og.Tokenizer(model)
        execute = lambda prompt: ort(og, model, tokenizer, prompt, args.max_tokens)
        versions = {"onnxruntime_genai": og.__version__}
    else:
        from tokenizers import Tokenizer
        encoder = Tokenizer.from_file(str(args.model_dir / "tokenizer.json"))
        execute = lambda prompt: llama(args.url, prompt, args.max_tokens, encoder)
        versions = {}
    load = time.perf_counter() - start
    def prompt(transcript):
        return render.render(messages=[{"role": "system", "content": SYSTEM},
            {"role": "user", "content": transcript}], tools=None,
            bos_token="<bos>", enable_thinking=False, add_generation_prompt=True)
    execute(prompt(CASES[-1][1]))  # excluded warmup
    cpu_before = sum(process.cpu_times()[:2])
    measure_start = time.perf_counter()
    rows = []
    for repeat in range(args.repeats):
        for name, transcript, expected in cases:
            result = execute(prompt(transcript))
            try:
                result["output"] = json.loads(result["raw"])
                result["valid_json"] = True
            except json.JSONDecodeError:
                result["output"] = None
                result["valid_json"] = False
            suffix = "-embed-noopt" if args.ort_no_embedding_optimization else ""
            result.update(label=f"{args.backend}-cpu-t{args.threads}-unconstrained{suffix}",
                          case=name, repeat=repeat, expected_evidence=expected,
                          cache=False, grammar=False)
            rows.append(result)
            print(name, round(result["complete_s"], 3), result["valid_json"], flush=True)
    measured_wall = time.perf_counter() - measure_start
    cpu_seconds = sum(process.cpu_times()[:2]) - cpu_before
    stop.set()
    watcher.join()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n")
    metadata = dict(backend=args.backend, threads=args.threads, versions=versions,
        context=4096, max_output=args.max_tokens, model_load_s=load,
        peak_rss_mib=max(rss) / 1024**2, memory_subject_pid=process.pid,
        system_available_mib=psutil.virtual_memory().available / 1024**2,
        process_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        measured_wall_s=measured_wall, measured_cpu_s=cpu_seconds,
        average_active_cores=cpu_seconds / measured_wall,
        swap_used_mib=psutil.swap_memory().used / 1024**2,
        embedding_optimization_disabled=args.ort_no_embedding_optimization,
        note="load timing excludes llama-server startup; RSS includes model load and warmup")
    args.out.with_suffix(".meta.json").write_text(json.dumps(metadata, indent=2) + "\n")


if __name__ == "__main__":
    main()
