# Throwaway spike #146; resumable bounded HTTP ranges for the large embedding.
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request

REPO = "justinchuby/gemma-4-e2b-it-onnx"
REVISION = "9bcf2cb1c2878b1c68a5f94db037272dfb278384"
NAME = "Q4_K_M/default/embedding/model.onnx.data"
ROOT = Path("/home/a.durynin/.cache/sessio-llm-spike-146/onnx-export")
SIZE = 5530517504
CHUNK = 64 * 1024**2


def fetch(index):
    start = index * CHUNK
    end = min(start + CHUNK, SIZE) - 1
    path = ROOT / "embedding-chunks" / f"{index:04d}"
    path.parent.mkdir(exist_ok=True)
    if path.exists() and path.stat().st_size == end - start + 1:
        return path
    for attempt in range(5):
        try:
            req = urllib.request.Request(
                f"https://huggingface.co/{REPO}/resolve/{REVISION}/{NAME}?download=true&part={index}",
                headers={"Range": f"bytes={start}-{end}"})
            with urllib.request.urlopen(req, timeout=30) as response:
                if response.status != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{SIZE}":
                    raise ValueError("Server did not honor the exact requested byte range")
                data = response.read()
            if len(data) != end - start + 1:
                raise ValueError("Truncated range")
            path.write_bytes(data)
            print(f"chunk {index + 1}/{(SIZE + CHUNK - 1) // CHUNK}", flush=True)
            return path
        except Exception as error:
            if attempt == 4:
                raise
            print(f"retry chunk {index}: {type(error).__name__}", flush=True)
            time.sleep(2)


def main():
    from huggingface_hub import HfApi
    info = HfApi().model_info(REPO, revision=REVISION, files_metadata=True)
    expected = next(item.lfs.sha256 for item in info.siblings if item.rfilename == NAME)
    count = (SIZE + CHUNK - 1) // CHUNK
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        paths = list(pool.map(fetch, range(count)))
    target = ROOT / NAME
    temporary = target.with_suffix(".assembled")
    digest = hashlib.sha256()
    with temporary.open("wb") as output:
        for path in paths:
            data = path.read_bytes()
            output.write(data)
            digest.update(data)
    if digest.hexdigest() != expected:
        raise ValueError("Embedding SHA256 mismatch; original file preserved")
    temporary.replace(target)
    print(json.dumps({"bytes": SIZE, "sha256": expected, "verified": True}), flush=True)


if __name__ == "__main__":
    main()
