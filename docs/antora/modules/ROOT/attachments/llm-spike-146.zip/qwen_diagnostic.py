"""CPU export diagnostic: fresh engine, same greedy prompt in two sessions."""
import argparse
import json
import time
from pathlib import Path
import litert_lm
from compare_cpu import template
from bench import CASES, SYSTEM

p=argparse.ArgumentParser()
p.add_argument('--fp32',action='store_true')
p.add_argument('--out',type=Path,required=True)
p.add_argument('--conversation',action='store_true')
args=p.parse_args()
root=Path('/home/a.durynin/.cache/sessio-llm-spike-146/litert-qwen4')
render=template(root/'chat_template.jinja')
rows=[]
if args.conversation:
    for i in range(2):
        with litert_lm.Engine(str(root/'Qwen3.5-4B_int8.litertlm'),
                backend=litert_lm.Backend.CPU(thread_count=4),max_num_tokens=4096,
                cache_dir=str(root/'compiled-cache')) as engine:
            start=time.perf_counter()
            with engine.create_conversation(system_message=SYSTEM,
                    extra_context={'enable_thinking':False},
                    sampler_config=litert_lm.SamplerConfig(top_k=1,temperature=0,seed=146),
                    max_output_tokens=160,enable_speculative_decoding=False) as conversation:
                result=conversation.send_message(CASES[0][1])
                raw=result.to_dict() if hasattr(result,'to_dict') else dict(result)
            rows.append(dict(session=i,fresh_engine=True,complete_s=time.perf_counter()-start,raw=raw))
            args.out.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
            print(i,raw,flush=True)
    raise SystemExit(0)
with litert_lm.Engine(str(root/'Qwen3.5-4B_int8.litertlm'),
        backend=litert_lm.Backend.CPU(thread_count=4),max_num_tokens=4096,
        activation_data_type=litert_lm.ActivationDataType.FLOAT32 if args.fp32 else None,
        cache_dir=str(root/'compiled-cache')) as engine:
    prompt=render.render(messages=[{'role':'system','content':SYSTEM},
        {'role':'user','content':CASES[0][1]}],tools=None,bos_token='<bos>',
        enable_thinking=False,add_generation_prompt=True)
    for i in range(2):
        start=time.perf_counter()
        with engine.create_session(apply_prompt_template=False,
                sampler_config=litert_lm.SamplerConfig(top_k=1,temperature=0,seed=146),
                max_output_tokens=160,enable_speculative_decoding=False) as session:
            session.run_prefill([prompt])
            raw=''.join(''.join(chunk.texts) for chunk in session.run_decode_async())
        rows.append(dict(session=i,fp32=args.fp32,complete_s=time.perf_counter()-start,raw=raw))
        args.out.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
        print(i,raw,flush=True)
