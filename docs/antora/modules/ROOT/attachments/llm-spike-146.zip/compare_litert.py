"""CPU-only LiteRT-LM spike, same raw rendered prompts as compare_cpu.py."""
import argparse
import dataclasses
import json
import resource
import threading
import time
from pathlib import Path

import litert_lm
import psutil
from tokenizers import Tokenizer
from compare_cpu import template
from bench import CASES, SYSTEM


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--template', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--repeats', type=int, default=4)
    p.add_argument('--mtp', action='store_true')
    p.add_argument('--cases-file', type=Path)
    p.add_argument('--max-tokens', type=int, default=160)
    p.add_argument('--text-only', action='store_true')
    p.add_argument('--prompt-file', type=Path)
    args = p.parse_args()
    system_prompt = args.prompt_file.read_text() if args.prompt_file else SYSTEM
    cases = json.loads(args.cases_file.read_text()) if args.cases_file else CASES
    render = template(args.template)
    encoder = Tokenizer.from_file(str(args.template.parent / 'tokenizer.json'))
    process = psutil.Process()
    rss = []
    stop = threading.Event()
    def monitor():
        while not stop.wait(.05):
            rss.append(process.memory_info().rss)
    watcher = threading.Thread(target=monitor, daemon=True)
    watcher.start()
    start = time.perf_counter()
    engine = litert_lm.Engine(str(args.model), backend=litert_lm.Backend.CPU(thread_count=4),
        vision_backend=None if args.text_only else litert_lm.Backend.CPU(thread_count=4),
        audio_backend=None if args.text_only else litert_lm.Backend.CPU(thread_count=4), max_num_tokens=4096,
        cache_dir=str(args.model.parent / 'compiled-cache'), enable_benchmark=True)
    load = time.perf_counter() - start
    def execute(transcript):
        prompt = render.render(messages=[{'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': transcript}], tools=None, bos_token='<bos>',
            enable_thinking=False, add_generation_prompt=True)
        reference_ids = encoder.encode(prompt, add_special_tokens=False).ids
        if len(reference_ids) + args.max_tokens > 4096:
            raise ValueError('Prompt exceeds context budget')
        # LiteRT's low-level session inserts BOS itself; its public tokenize()
        # treats the literal <bos> as ordinary text. Other control tokens match.
        has_bos = prompt.startswith('<bos>')
        prompt = prompt.removeprefix('<bos>')
        ids = engine.tokenize(prompt)
        if ids != (reference_ids[1:] if has_bos else reference_ids):
            raise ValueError('Tokenizer mismatch beyond BOS handling')
        start = time.perf_counter()
        first = None
        text = ''
        with engine.create_session(apply_prompt_template=False,
                sampler_config=litert_lm.SamplerConfig(top_k=1, temperature=0, seed=146),
                max_output_tokens=args.max_tokens, enable_speculative_decoding=args.mtp) as session:
            session.run_prefill([prompt])
            for chunk in session.run_decode_async():
                delta = ''.join(chunk.texts)
                if delta and first is None:
                    first = time.perf_counter() - start
                text += delta
            elapsed = time.perf_counter() - start
            info = dataclasses.asdict(session.get_benchmark_info())
            if info['last_prefill_token_count'] != len(reference_ids):
                raise ValueError('Session input count differs from reference including BOS')
        try:
            output = json.loads(text)
        except json.JSONDecodeError:
            output = None
        return dict(raw=text, ttft_s=first, complete_s=elapsed, valid_json=output is not None,
            output=output, input_tokens=info['last_prefill_token_count'],
            output_tokens=info['last_decode_token_count'], timings=info, tokenizer_parity=True,
            truncated=info['last_decode_token_count'] >= args.max_tokens)
    execute(CASES[-1][1])  # Same short excluded warmup for both runners.
    cpu_start = sum(process.cpu_times()[:2])
    wall_start = time.perf_counter()
    rows = []
    for repeat in range(args.repeats):
        for name, transcript, expected in cases:
            result = execute(transcript)
            result.update(label='litert-cpu-t4-mtp' if args.mtp else 'litert-cpu-t4',
                case=name, repeat=repeat, expected_evidence=expected, grammar=False, cache=False)
            rows.append(result)
            print(name, round(result['complete_s'], 3), result['input_tokens'],
                  result['output_tokens'], result['valid_json'], flush=True)
    wall = time.perf_counter() - wall_start
    cpu = sum(process.cpu_times()[:2]) - cpu_start
    stop.set()
    watcher.join()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    args.out.with_suffix('.meta.json').write_text(json.dumps(dict(
        backend='litert', version='0.18.0', threads=4, context=4096, max_output=args.max_tokens,
        model_path=str(args.model.resolve()),
        mtp=args.mtp, model_load_s=load, peak_rss_mib=max(rss)/1024**2,
        process_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        measured_wall_s=wall, measured_cpu_s=cpu, average_active_cores=cpu/wall,
        note='Fresh session per request; compiled weight cache allowed; no prompt reuse.'), indent=2)+'\n')
    engine.close()


if __name__ == '__main__':
    main()
