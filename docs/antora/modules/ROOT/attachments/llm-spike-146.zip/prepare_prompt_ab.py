"""Materialize the reviewed guide's exact candidates, preserving baseline."""
import json
import re
from pathlib import Path
from bench import SYSTEM, CASES
from rolling_state import PATCH_SYSTEM

root = Path(__file__).parent
guide = (root.parent.parent / 'docs/live-llm-gemma-prompt-guides.md').read_text()
blocks = re.findall(r'```(text|json)\n(.*?)\n```', guide, re.S)
destination = root / 'prompts'
destination.mkdir(exist_ok=True)
extract = blocks[0][1]
examples = blocks[1][1]
patch = PATCH_SYSTEM + '\n' + blocks[2][1]
patch_example = '\nПример входа:\n' + blocks[3][1] + '\nПравильный ответ:\n' + blocks[4][1]
for name, extraction, operations in [
    ('baseline', SYSTEM, PATCH_SYSTEM),
    ('rules', extract, patch),
    ('examples', extract + '\n\n' + examples, patch + '\n\n' + patch_example),
]:
    (destination / f'{name}-extract.txt').write_text(extraction + '\n')
    (destination / f'{name}-patch.txt').write_text(operations + '\n')

# Different wording/actions from the development examples and original fixture.
heldout = [
    ['heldout_accept', '[h1] Анна: До среды подготовьте два вопроса для обсуждения.\n[h2] Борис: Хорошо, подготовлю два вопроса до среды.', ['h1', 'h2']],
    ['heldout_proposal', '[h1] Анна: Может, отправите отчёт к четвергу?\n[h2] Борис: Пока не могу обещать, сначала уточню.', []],
    ['heldout_refusal', '[h1] Борис: Я не беру на себя обязательство звонить ежедневно.\n[h2] Анна: Тогда просто обсудим возможности.', []],
    ['heldout_neutral', '[h1] Анна: Вчера было солнечно.\n[h2] Борис: Да, погода порадовала.', []],
    ['heldout_correction', '[h1] Борис: Отправлю таблицу во вторник.\n[h2] Борис: Поправка: отправлю таблицу в четверг.\n[h3] Анна: Хорошо, жду таблицу в четверг.', ['h2','h3']],
]
(root / 'prompt-ab-cases.json').write_text(json.dumps(list(CASES) + heldout, ensure_ascii=False, indent=2) + '\n')
