#!/usr/bin/env bash
# Throwaway sequential CPU-only artifact comparison; verify weights first.
set -euo pipefail
cd "$(dirname "$0")"
spike_cache=/home/a.durynin/.cache/sessio-llm-spike-146
spike_python="$spike_cache/litert-venv/bin/python"
spike_reference="$spike_cache/litert-qwen4"
spike_model="$spike_reference/Qwen3.5-4B_int8.litertlm"
systemd-run --user --scope -p MemoryMax=10G -p MemorySwapMax=0 \
  "$spike_python" compare_litert.py --text-only --model "$spike_model" \
  --template "$spike_reference/chat_template.jinja" --out results/qwen4-short.json \
  >results/qwen4-short.log 2>&1
echo 'Qwen4 short complete'
systemd-run --user --scope -p MemoryMax=10G -p MemorySwapMax=0 \
  "$spike_python" compare_litert.py --text-only --max-tokens 256 --cases-file long-cases.json \
  --model "$spike_model" --template "$spike_reference/chat_template.jinja" \
  --out results/qwen4-long.json >results/qwen4-long.log 2>&1
echo 'Qwen4 long complete'
systemd-run --user --scope -p MemoryMax=10G -p MemorySwapMax=0 \
  "$spike_python" rolling_state.py --text-only --patch --mutation-probe --no-mtp --backend litert \
  --litert-model "$spike_model" --model-dir "$spike_reference" \
  --cases-file long-cases.json --windows-file rolling-windows.json \
  --out results/qwen4-patch.json >results/qwen4-patch.log 2>&1
echo 'Qwen4 patch complete'
